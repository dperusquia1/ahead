import { execFileSync } from "node:child_process";
import { existsSync, lstatSync, readFileSync, readdirSync } from "node:fs";
import { resolve } from "node:path";

const root = resolve(import.meta.dirname, "..");
// ZIP downloads have no Git history. Never accidentally inspect a parent repo.
let ownRepository = false;
try { ownRepository = execFileSync("git", ["rev-parse", "--show-toplevel"], { cwd: root, encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] }).trim() === root; } catch { /* Source ZIP. */ }
function walk(directory = "") {
  return readdirSync(resolve(root, directory), { withFileTypes: true }).flatMap(entry => {
    if (!directory && [".git", "node_modules", "dist"].includes(entry.name)) return [];
    const name = directory ? `${directory}/${entry.name}` : entry.name;
    return entry.isDirectory() ? walk(name) : [name];
  });
}
const files = ownRepository ? [...new Set(execFileSync("git", ["ls-files", "-z", "--cached", "--others", "--exclude-standard"], { cwd: root, encoding: "utf8" }).split("\0").filter(Boolean))] : walk();
const issues = [];
const forbidden = (process.env.AHEAD_FORBIDDEN_STRINGS || "").split(",").filter(Boolean);
function inspect(file, buffer) {
  if (file.endsWith(".ics") && file !== "examples/sample-calendar.ics") issues.push(`${file}: unexpected calendar data`);
  if (/(^|\/)(\.env(?:\.|$)|\.ahead|\.aws|\.codex|\.openai|node_modules|outputs|private|dist)(\/|$)|\.(pem|key|p12|sqlite|db|pdf|docx|xlsx|heic)$/i.test(file)) issues.push(`${file}: private or generated file category`);
  if (/\.(png|jpg|jpeg|webp|ico)$/i.test(file)) return;
  const content = buffer.toString("utf8");
  const patterns = [
    /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/,
    /(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}|sk-[A-Za-z0-9_-]{30,}|AKIA[A-Z0-9]{16})/,
    /\/Users\/[A-Za-z][A-Za-z0-9_.-]+\//,
  ];
  if (patterns.some(pattern => pattern.test(content))) issues.push(`${file}: possible credential or machine-specific path`);
  if (forbidden.some(value => content.toLowerCase().includes(value.toLowerCase()))) issues.push(`${file}: private identifier match`);
}
for (const file of files) {
  const full = resolve(root, file);
  if (!existsSync(full)) continue;
  if (lstatSync(full).isSymbolicLink()) { issues.push(`${file}: symbolic links are not allowed in the source package`); continue; }
  if (lstatSync(full).isFile()) inspect(file, readFileSync(full));
}
const objects = ownRepository ? execFileSync("git", ["rev-list", "--objects", "--all"], { cwd: root, encoding: "utf8" }).trim().split("\n").filter(Boolean) : [];
let historicalBlobs = 0;
for (const line of objects) {
  const space = line.indexOf(" ");
  if (space < 0) continue;
  const hash = line.slice(0, space); const file = line.slice(space + 1);
  const type = execFileSync("git", ["cat-file", "-t", hash], { cwd: root, encoding: "utf8" }).trim();
  if (type !== "blob") continue;
  historicalBlobs++;
  inspect(file, execFileSync("git", ["cat-file", "blob", hash], { cwd: root, maxBuffer: 10_000_000 }));
}
if (!files.includes("LICENSE") || !files.includes("package-lock.json")) issues.push("Missing license or lockfile.");
if (issues.length) { console.error(issues.join("\n")); process.exitCode = 1; }
else console.log(`Release audit passed: ${files.length} source files and ${historicalBlobs} historical blobs checked. No credential-pattern matches or excluded private paths found. This is a scoped check, not a guarantee of zero secrets.`);
