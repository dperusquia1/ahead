# Security and privacy

## Scope of this release

Version 0.2 is a client-side local planner. It does not have a user-account backend, token storage, an LMS session, a model connection, or a scheduler. It must not be deployed as a connected multi-student service.

Calendar files are parsed in memory and saved to this browser's local storage after confirmation. Notes, dates, source links, and completion are not encrypted. Other people or extensions with access to the same browser profile may access them. Host access logs may record ordinary website visits; this is not invisible browsing.

The app makes no outbound API calls. Opening an original source link is a user-directed navigation that may create normal access logs. Backups and exports contain user data; keep them out of repositories and shared folders.

## Current controls

- React renders imported text as text; imported HTML is never executed.
- Source links permit only http(s), reject credentials and common secret query parameters, and use noreferrer.
- File limits and schema validation apply before import/restore.
- Stable source/UID identity prevents duplicate tasks on same-source re-import.
- A stale-tab guard prevents silently overwriting another tab's changes.
- Failed storage writes are shown, with backup available.
- The production build adds a Content Security Policy limiting assets and connections to its own origin. Local Vite development uses its normal reload behavior.
- No remote image, video, attachment, or URL is fetched from imported calendar descriptions.

These controls do not replace an independent security review.

## Reporting

Do not post credentials, private calendar feeds, student records, or exploitable security details in public issues. Use **Security → Report a vulnerability** when the repository owner has enabled GitHub private vulnerability reporting. If that button is unavailable, open a minimal issue asking the owner to enable a private reporting route, without disclosing the vulnerability.

Maintainers must enable private vulnerability reporting before inviting external testers to a hosted preview.

## Before any live school connector

Use approved provider OAuth/API access, minimal read permissions, authenticated per-user authorization, encrypted server-side credential storage, revocation, deletion, and retention controls. Do not trust user identity headers unless a verified gateway strips attacker-supplied values. Never collect school passwords, reuse browser cookies, or accept broad personal access tokens as a shortcut.

Test two-user isolation, expired/revoked grants, partial scans, rate limits, safe pagination, URL validation/SSRF, and checkpoint handling with synthetic data. Exclude student discussions/replies, other students' submissions, answer keys, protected feedback, and active assessment content. Email needs separate consent and its own connector.

See [the connector contract](docs/CONNECTORS.md).
