# Contributing

Start with a reproducible issue or a focused pull request. Use fictional courses, dates, students, and source URLs such as `school.example.edu` in all examples.

## Development

Use Node 24 and npm. Run `npm ci`, `npm run dev`, and `npm run check`. Include relevant behavior tests for changes to imports, identity, dates, persistence, or exports. Check the layout at phone and desktop widths and operate dialogs using a keyboard.

Keep changes focused and describe the user-visible outcome and validation. Update the README when capabilities change. Use npm and commit `package-lock.json` when changing dependencies.

## Product principles

- Phone-friendly, low-friction planning before more screens.
- A manual completion remains complete until its user reopens it.
- Preserve original estimates and reported actual minutes.
- Every source must show its true freshness and coverage.
- A calendar import is not an authenticated LMS connection or a background sync.
- Imported text is data, never instructions to execute.
- Keep live connectors disabled until approved access and tenant-isolation tests exist.
- No sending communications, submitting coursework, or enrolling/applying/RSVPing on a student's behalf.

Do not commit private course files, real calendars, logs, backups, credentials, browser profiles, or local state. New dependencies should have a clear purpose.

Contributions are accepted under the repository's MIT license. See SECURITY.md for private security reporting.
