# Connector architecture

The current calendar import is a browser-only file adapter. The live provider registry deliberately throws instead of returning a fabricated connected state.

## Boundary

A future server adapter implements `LearningPlatformConnector` in `connectors/types.ts`. The server supplies an authenticated `ConnectionContext`; do not accept a browser-provided user ID as authorization. Credentials are obtained from a server secret store, not included in this interface or any browser bundle.

Each source record has a canonical key: provider domain, course ID, object type, and stable object ID. Titles and dates are mutable attributes. Every snapshot reports attempted time, last successful check, per-type coverage, errors, and a checkpoint. Failed or partial scans must retain the previous successful checkpoint.

## Ownership

Every query, mutation, file download, background job, and cache must enforce the account/connection owner. A course ID alone is not an authorization boundary. Tests must create two synthetic users and prove that guessing IDs, URLs, and cursors never crosses between them.

The browser-only release has no tenant service: data is local to one browser profile. It must not be reused as server authentication.

## Read boundaries

Read authorized published/unlocked instructor material only. For discussions and quizzes, collect permitted title/date metadata without opening student replies or active questions/answers. Avoid classmates' profiles/work, answer keys, grades, and protected feedback. Restrict per-course study use where required. Never submit, send, reply, invite, RSVP, or change coursework through a planner connector.

## Network handling

Use configured provider origins, validate authorization redirects and OAuth state, protect the callback/session, and restrict redirect/pagination targets to approved origins. Apply request limits, timeouts, retry/backoff, and cancellation. Never use arbitrary student-entered URLs as unrestricted server fetch targets.

## Completion

Keep user progress separate from source revisions. A date/title update must not reset manual completion, reported actual time, or original estimates. An absent object is not proof of deletion; explicit unavailable status and repeated successful scans need deliberate handling.

## Validation before rollout

Validate actual OAuth/API behavior against a developer-controlled Canvas instance with synthetic records. Mock tests are useful but do not establish institution compatibility. Then verify the deployed service's scheduler, token encryption/revocation, account isolation, notification privacy, and restoration behavior.

Official starting points:
- [Canvas OAuth](https://developerdocs.instructure.com/services/canvas/oauth2/file.oauth)
- [Canvas API](https://developerdocs.instructure.com/services/canvas)
- [ICAL.js API](https://kewisch.github.io/ical.js/api/)

