# Release validation — 0.2.0

Checked October 8, 2026. This records validation of the local planner, not a live school integration or hosted service.

| Check | Result |
| --- | --- |
| Clean dependency install from the release lockfile | `npm ci` passed with Node 24.19.0 / npm 11.6.2 |
| Code quality and types | ESLint and TypeScript passed |
| Behavior tests | 18 passed, zero failed |
| Production build | Vite 8.3.3 static build passed |
| Dependency advisory audit, including development dependencies | `npm audit` reported zero known vulnerabilities on the check date |
| Public source scan | No configured private-identifier matches, credential-pattern matches, or excluded private-file categories found |
| Existing Git history | None in the release candidate; no private application history copied |
| Browser smoke check | Task creation, calendar import, completion persisted after reload, demo workspace, settings, and stale-tab write protection verified |
| Responsive review | 390 × 844 phone and 1366 × 900 desktop layouts inspected; phone document had no horizontal overflow |
| Browser console | No warnings/errors observed during the smoke check |

Tests cover invalid backups, identity collisions, credential-bearing links, time zones and DST handling, embedded time zones, unsupported events, revision selection within a file, same-source re-import, preserved completion and time records, explicit cancellations, and private/no-attendee calendar export with alarm rules.

The screenshots in this folder contain fictional demo tasks only. Browser smoke checks used synthetic test records, not student information.

## Not established by these checks

- A full independent security or accessibility audit; Safari/Firefox compatibility; real-device coverage.
- Any connection to a school account, inbox, calendar account, or live learning-platform API.
- Institution approval, multi-user authentication/isolation, encrypted server storage, or background scheduling.
- A hosted deployment or an executed GitHub Actions run. The provided workflows need verification after the owner creates the repository.
- A guarantee that all possible secrets or future dependency vulnerabilities are absent. Repeat the audit before each release.

See [publishing](PUBLISHING.md) for the upload checklist and [the roadmap](ROADMAP.md) for the connected-service requirements.
