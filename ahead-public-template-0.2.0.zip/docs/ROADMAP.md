# Ahead roadmap

## Available in 0.2

A portable React/Vite local planner: task editing, preparation notes, completion, preserved original estimates, actual time, filters, week view, calendar import/re-import, change history, archive/restore, backup validation, and private calendar export. Source code, build configuration, a reusable connector contract, synthetic fixtures, and GitHub workflows are included.

This release lets people use and extend the planner. It does not fulfill the connected-service goal below.

## Next: one link, each student's own school

1. Build a separate authenticated server service with strict tenant boundaries, migrations, encrypted per-user tokens, and retention/revocation/deletion controls.
2. Implement Canvas first through institution-enabled OAuth and the documented API. Use a developer-controlled Canvas instance with synthetic students and classes for end-to-end validation before a school pilot.
3. Track each intended course and object type separately: assignments/date metadata, required preparation Pages, official announcements, and permitted materials. Advance checkpoints only after full intended coverage; show partial/disconnected sources.
4. Run incremental synchronization on a real server scheduler, independent of the browser or chat. Handle pagination, rate limits, retries, revisions, and deletions explicitly.
5. Deliver quiet, student-only reminders and calendar updates with opt-in consent. Preserve completion, original estimates, actual minutes, and calendar identity.
6. Add Moodle and Blackboard through their own authorized adapters. School email is a separate optional integration.
7. Add source-grounded study help only for permitted material, with user-scoped retrieval, citations, clear source policies, and explicit model cost limits.

No school approval, institution OAuth key, account service, background scheduler, or notification delivery is provided by a GitHub template. The public UI must keep planned integrations unavailable until their implementation and deployment checks pass.

## Later improvements

Recurring calendar events; explicit floating-timezone selection per source; previewing changes before a re-import; accessible offline app caching; an opt-in study timer; opt-in encrypted backup formats. These are ideas, not shipped capabilities.

