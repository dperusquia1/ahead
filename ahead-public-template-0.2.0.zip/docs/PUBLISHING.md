# Publish this repository

The source package contains fictional fixtures and no previous private application history. The original personal application is separate.

## Final local check

```sh
npm ci
npm run release:check
npm audit --omit=dev
```

Review the files being uploaded. Do not add your `.env`, backups, calendar exports, coursework, browser data, or a copy of a private repository's history. Automated pattern scans are a supplement to review, not proof that every possible secret is absent.

## Create the GitHub template

1. Create a new public repository on GitHub with the name you want.
2. Upload this directory's source files, including dotfiles such as `.github/`, `.gitignore`, and `.nvmrc`. Keep generated `node_modules/` and `dist/` out of source control.
3. In repository Settings, enable **Template repository** so others can use **Use this template**.
4. Enable GitHub private vulnerability reporting under the repository security settings.
5. Check that the CI workflow passes, and review the MIT license and README before announcing the release.

No GitHub repository or remote is created by the setup commands. The `private: true` field in package.json prevents accidental npm package publishing; it does not stop public GitHub hosting.

## Optional GitHub Pages preview

A static preview of the planner can be hosted on GitHub Pages:

1. In Settings → Pages, choose **GitHub Actions** as the build source.
2. In Actions, open **Publish preview to GitHub Pages**, then choose **Run workflow**.
3. Open the deployment URL after the workflow finishes.

The Pages workflow is manual. A push does not automatically publish a website. Hosting the planner does not add school sign-in, shared accounts, cloud data storage, or background updates. Every visitor gets their own local browser workspace; people sharing a browser profile share its workspace.

The build uses relative asset paths, so repository subpaths are supported. You may also host the generated `dist/` directory with another static hosting provider. Use a dedicated origin; other scripts served from the same origin can access its browser storage.

[Vite static deployment documentation](https://vite.dev/guide/static-deploy.html).
