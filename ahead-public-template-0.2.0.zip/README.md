# Ahead

**Your coursework, with a little foresight.**

Ahead is an open-source student planner. Import a calendar file from a school portal, add the readings and preparation it leaves out, and organize the work around the time you have.

This release is a working **local planner and integration starter**. It does **not** sign in to Canvas, Moodle, Blackboard, or school email, and it does not run background synchronization. See [the roadmap](docs/ROADMAP.md) for the connected service.

![Ahead desktop planner with fictional sample tasks](docs/preview-desktop.jpg)

[Phone preview](docs/preview-mobile.jpg) · [Release validation](docs/VALIDATION.md)

## What works

- Create and edit tasks, assignments, preparation, quizzes, discussions, and meetings.
- Track completion, priority, estimated time, original estimates, actual minutes, and preparation notes.
- Search by course, filter by status, and find work that fits 15, 30, or 60 minutes.
- Review the next seven days and past-due items.
- Import supported `.ics` calendar events locally, with a preview and skipped-event report.
- Re-import the same calendar to update dates without resetting completion or personal time records.
- Keep a change history, archive tasks, and restore archived work.
- Export a private/free calendar with optional display alarms and download/restore JSON backups.
- Try a fictional sample workspace without replacing your own tasks.

There are no school passwords, personal access tokens, analytics, advertising, external fonts, AI calls, or server accounts in this build. Your planner is saved in this browser profile. It is **not encrypted or protected by an Ahead login**; use a personal browser profile and keep backups.

## Run locally

Use **Node.js 24 LTS**, which includes npm. Node 22.13+ is also supported.

Download this repository or use GitHub's **Use this template**, then open a terminal in its folder:

```sh
npm ci
npm run dev
```

Open the local URL shown in the terminal (normally `http://127.0.0.1:5173`). Start with a task, a calendar export, or **Explore a sample week**. No environment file or credential is required.

## Calendar import

1. Download an iCalendar (`.ics`) export from your portal. In Canvas, look under **Calendar → Calendar Feed**. Keep private feed addresses to yourself.
2. In Ahead, choose **Import calendar**, name the source, and select the file.
3. Review supported and skipped events before importing.
4. Next time, select **Update [calendar name]** and import a fresh export from the same source.

The importer supports non-recurring `VEVENT` entries with stable UIDs: UTC timestamps, date-only entries, IANA time zones, embedded `VTIMEZONE` definitions, and floating times interpreted in the displayed browser time zone. Ambiguous floating/IANA clock times, unknown zones, invalid dates, recurring entries, and events without UIDs are reported rather than guessed. Embedded time zones follow the calendar's own rules. `VTODO` is not supported. Limits: 2 MB per file/workspace, 2,000 tasks, 100 sources.

Calendar timestamps may represent deadlines **or event starts**. Confirm their meaning in the original portal, then set the task type. An imported date does not prove a submission status. Files may omit Pages, announcements, preparation, materials, undated work, or courses not selected in the original calendar.

Missing items in a later file are retained. Explicit cancellations are retained for review. Re-import updates source-controlled titles/dates/descriptions/links; your notes, course label, type, priority, estimates, actual time, completion, and archive state are preserved. Calendar files do not provide a reliable cross-file revision cursor, so always use the latest export.

## Back up and export

Under **Settings**:

- **Download backup** saves the entire local workspace. Restore previews the task count and requires confirmation before replacing the current workspace.
- **Export calendar** creates a static `.ics` copy with stable event IDs, `CLASS:PRIVATE`, `TRANSP:TRANSPARENT`, and no attendees or organizer.
- Optional alarms use priority-based intervals. Completed items and date-only items have none; elapsed alarm times are omitted.
- **Clear this browser's planner** offers a backup first and asks for confirmation.

Calendar import behavior varies by calendar app. An export is not a subscription: editing/completing a task later does not update a previously imported event or remove its reminders. Import your export into a private calendar and check its privacy/reminder settings.

## Test and build

```sh
npm run check          # lint, behavior tests, TypeScript, production build
npm run audit:release  # public-file and history checks
npm run preview       # inspect the build locally
```

`dist/` contains the static app. It supports a domain root or a repository subpath through relative asset paths. A service worker and offline asset cache are not included; local data persistence does not mean the website will load without a connection.

GitHub Actions runs the checks on pushes and pull requests. The optional Pages workflow runs **only when you start it manually**. See [publishing](docs/PUBLISHING.md).

## Architecture and contributions

- `src/model.ts` — typed planner, validation, dates, and synthetic demo.
- `src/calendar.ts` — calendar parsing, identity-preserving merge, export.
- `src/App.tsx` — phone-friendly UI and guarded browser persistence.
- `connectors/` — contract for future authorized server adapters; real providers fail closed.
- `tests/` — behavior checks for imports, dates, completion, backups, and exports.

Read [CONTRIBUTING.md](CONTRIBUTING.md), [connector design](docs/CONNECTORS.md), and [SECURITY.md](SECURITY.md). The [roadmap](docs/ROADMAP.md) distinguishes shipped functions from the future multi-student service.

Released under the [MIT license](LICENSE). Ahead is independent and is not endorsed by any school or learning-platform provider.
