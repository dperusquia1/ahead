# Changelog

## 0.2.0 — 2026-10-08

First portable local-planner release candidate.

- Added task editing, preparation notes, priorities, manual completion, original estimates, and actual minutes.
- Added course/status/duration filters, next-week view, and past-due status.
- Added local calendar import with preview, time-zone handling, stable identity, preserved progress, cancellation review, and change history.
- Added JSON backup/restore, archive/restore, private calendar export, and optional display alarms.
- Added an isolated fictional demo, phone-first layout, visible source coverage, and storage/conflict warnings.
- Added validation tests, pinned dependencies and workflow actions, release scanning, MIT licensing, and publishing/security/contribution guides.
- Live Canvas, Moodle, and Blackboard connections remain unavailable until approved server adapters are implemented and verified.
