import assert from "node:assert/strict";
import test from "node:test";
import { demoPlanner, emptyPlanner, isOverdue, makeTask, parseBackup, safeUrl } from "../src/model.ts";
import { connectorRegistry } from "../connectors/registry.ts";

test("backup round trip preserves completion, original estimate, zero actual minutes and notes", () => {
  const task = makeTask({ title: "Example", completedAt: "2026-01-12T12:00:00Z", originalEstimateMinutes: 90, estimatedMinutes: 45, actualMinutes: 0, notes: "Bring a calculator." });
  const planner = { ...emptyPlanner(), tasks: [task] };
  assert.deepEqual(parseBackup(JSON.stringify(planner)), planner);
});
test("invalid and oversized backups do not become a new workspace", () => {
  for (const value of [null, {}, { schemaVersion: 2, tasks: [], sources: [], changes: [] }]) assert.throws(() => parseBackup(JSON.stringify(value)));
  const task = makeTask({ title: "Example", dueAt: "2026-02-30", dateOnly: true });
  assert.throws(() => parseBackup(JSON.stringify({ ...emptyPlanner(), tasks: [task] })), /date/i);
  assert.throws(() => parseBackup(" ".repeat(2_000_001)), /large/i);
  assert.throws(() => parseBackup(JSON.stringify({ ...emptyPlanner(), tasks: [makeTask({ title: "Bad time", actualMinutes: -1 })] })), /number/i);
});
test("backups reject duplicate identity and unknown calendar ownership", () => {
  const task = makeTask({ title: "One" });
  assert.throws(() => parseBackup(JSON.stringify({ ...emptyPlanner(), tasks: [task, task] })), /Duplicate/);
  assert.throws(() => parseBackup(JSON.stringify({ ...emptyPlanner(), tasks: [{ ...task, sourceId: "unknown", sourceUid: "uid" }] })), /unknown source/);
});
test("source links cannot execute scripts or expose embedded credentials", () => {
  for (const url of ["javascript:alert(1)", "data:text/html,hello", "https://user:password@example.edu/", "https://example.edu/?access_token=secret"]) assert.equal(safeUrl(url), null);
  assert.equal(safeUrl("https://school.example.edu/courses/123?module_item_id=456"), "https://school.example.edu/courses/123?module_item_id=456");
});
test("date-only tasks are not overdue before the end of their local day", () => {
  const task = makeTask({ title: "Date only", dueAt: "2026-10-07", dateOnly: true });
  assert.equal(isOverdue(task, new Date(2026, 9, 7, 23, 59)), false);
  assert.equal(isOverdue(task, new Date(2026, 9, 8, 0, 0)), true);
  assert.equal(isOverdue({ ...task, completedAt: "2026-10-07T12:00:00Z" }, new Date(2026, 9, 8)), false);
  assert.equal(isOverdue({ ...task, cancelled: true }, new Date(2026, 9, 8)), false);
});
test("demo is synthetic and callers receive independent workspaces", () => {
  const a = demoPlanner(new Date("2026-01-01T12:00:00Z")); const b = demoPlanner(new Date("2026-01-01T12:00:00Z"));
  a.tasks[0].title = "Changed";
  assert.notEqual(a.tasks[0].title, b.tasks[0].title);
  assert.ok(b.tasks.every(t => !t.sourceUrl && !t.sourceId));
  assert.deepEqual(parseBackup(JSON.stringify(b)), b);
});
test("all live provider connectors fail closed", async () => {
  for (const provider of connectorRegistry) {
    assert.equal(provider.state, "planned");
    await assert.rejects(provider.readSnapshot({ userId: "sample-user", connectionId: "sample-connection", allowedCourseIds: [] }), /not configured/);
  }
});
