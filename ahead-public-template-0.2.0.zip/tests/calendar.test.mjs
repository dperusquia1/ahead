import assert from "node:assert/strict";
import test from "node:test";
import ICAL from "ical.js";
import { exportCalendar, mergeCalendar, parseCalendar, zonedTimestamp } from "../src/calendar.ts";
import { emptyPlanner, makeTask } from "../src/model.ts";

const wrap = body => `BEGIN:VCALENDAR\r\nVERSION:2.0\r\n${body}\r\nEND:VCALENDAR`;
const event = (uid, date = "20261008T160000Z", extra = "") => `BEGIN:VEVENT\r\nUID:${uid}\r\nDTSTART:${date}\r\nSUMMARY:Sample task\r\n${extra}\r\nEND:VEVENT`;
const parse = text => parseCalendar(text, "America/New_York");

test("calendar import parses unfolded text, UTC dates and safe source links", () => {
  const data = parse(wrap(event("task-1", undefined, "DESCRIPTION:Bring notes\\nRead pages 1–5.\r\nURL:https://school.example.edu/task/1")));
  assert.equal(data.events[0].dueAt, "2026-10-08T16:00:00.000Z");
  assert.equal(data.events[0].description, "Bring notes\nRead pages 1–5.");
  assert.equal(data.events[0].url, "https://school.example.edu/task/1");
  assert.equal(data.skipped, 0);
});
test("date-only values stay dates, and IANA/floating time zones are explicit", () => {
  const allDay = wrap("BEGIN:VEVENT\r\nUID:date-only\r\nDTSTART;VALUE=DATE:20261008\r\nSUMMARY:One day\r\nEND:VEVENT");
  assert.equal(parse(allDay).events[0].dueAt, "2026-10-08");
  assert.equal(parse(allDay).events[0].dateOnly, true);
  const named = wrap(event("named").replace("DTSTART:20261008T160000Z", "DTSTART;TZID=America/New_York:20261008T090000"));
  assert.equal(parse(named).events[0].dueAt, "2026-10-08T13:00:00.000Z");
  assert.equal(parse(wrap(event("floating", "20261008T090000"))).events[0].dueAt, "2026-10-08T13:00:00.000Z");
});
test("DST gaps and repeated clock times are rejected instead of guessed", () => {
  assert.throws(() => zonedTimestamp("2026-03-08T02:30:00", "America/New_York"), /nonexistent/);
  assert.throws(() => zonedTimestamp("2026-11-01T01:30:00", "America/New_York"), /ambiguous/);
});
test("embedded calendar time zones are resolved without a network request", () => {
  const timezone = "BEGIN:VTIMEZONE\r\nTZID:School/Eastern\r\nBEGIN:STANDARD\r\nDTSTART:19701101T020000\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0500\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nDTSTART:19700308T020000\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0400\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nEND:VTIMEZONE";
  const localEvent = event("embedded").replace("DTSTART:20261008T160000Z", "DTSTART;TZID=School/Eastern:20261008T090000");
  assert.equal(parse(wrap(timezone + "\r\n" + localEvent)).events[0].dueAt, "2026-10-08T13:00:00.000Z");
});
test("unsupported and invalid events report incomplete coverage", () => {
  const data = parse(wrap([event("valid"), event("repeat", undefined, "RRULE:FREQ=WEEKLY"), event("bad", "20260230T120000Z"), event("unknown").replace("DTSTART:", "DTSTART;TZID=Not/AZone:").replace("160000Z", "160000")].join("\r\n")));
  assert.equal(data.events.length, 1); assert.equal(data.skipped, 3); assert.equal(data.warnings.length, 3);
  assert.throws(() => parse("no calendar"));
  assert.throws(() => parse(wrap(event("", "20261008T160000Z"))), /UID/);
});
test("latest duplicate revision in one file wins", () => {
  const data = parse(wrap([event("same", "20261008T160000Z", "SEQUENCE:1"), event("same", "20261009T160000Z", "SEQUENCE:2"), event("same", "20261007T160000Z", "SEQUENCE:0")].join("\r\n")));
  assert.equal(data.events.length, 1); assert.equal(data.events[0].dueAt, "2026-10-09T16:00:00.000Z");
});
test("reimport preserves personal progress and identity while reporting date changes", () => {
  let planner = mergeCalendar(emptyPlanner(), parse(wrap(event("a"))), "source-1", "Sample course");
  const originalId = planner.tasks[0].id;
  Object.assign(planner.tasks[0], { completedAt: "2026-10-07T10:00:00Z", originalEstimateMinutes: 80, estimatedMinutes: 50, actualMinutes: 42, notes: "My notes", kind: "preparation", course: "My label" });
  planner = mergeCalendar(planner, parse(wrap(event("a", "20261009T170000Z"))), "source-1", "Sample course");
  assert.equal(planner.tasks.length, 1); assert.equal(planner.tasks[0].id, originalId);
  for (const [key, value] of Object.entries({ completedAt: "2026-10-07T10:00:00Z", originalEstimateMinutes: 80, estimatedMinutes: 50, actualMinutes: 42, notes: "My notes", kind: "preparation", course: "My label" })) assert.equal(planner.tasks[0][key], value);
  assert.match(planner.changes[0].detail, /Date changed/);
  const changes = planner.changes.length;
  planner = mergeCalendar(planner, parse(wrap(event("a", "20261009T170000Z"))), "source-1", "Sample course");
  assert.equal(planner.changes.length, changes);
});
test("missing entries never delete tasks; explicit cancellation is retained", () => {
  let planner = mergeCalendar(emptyPlanner(), parse(wrap(event("a"))), "source-1", "Sample");
  planner = mergeCalendar(planner, parse(wrap(event("b"))), "source-1", "Sample");
  assert.equal(planner.tasks.length, 2);
  const cancel = wrap("BEGIN:VEVENT\r\nUID:a\r\nSTATUS:CANCELLED\r\nEND:VEVENT");
  planner = mergeCalendar(planner, parse(cancel), "source-1", "Sample");
  assert.equal(planner.tasks[0].cancelled, true); assert.equal(planner.tasks.length, 2);
});
test("identical UIDs from separate calendars remain separate", () => {
  let planner = mergeCalendar(emptyPlanner(), parse(wrap(event("a"))), "first", "First");
  planner = mergeCalendar(planner, parse(wrap(event("a"))), "second", "Second");
  assert.equal(planner.tasks.length, 2);
});
test("export is private, nonblocking and has no recipients or invitation method", () => {
  const task = makeTask({ title: "Line 1\nATTENDEE:fake@example.edu", dueAt: "2027-10-07T16:00:00Z", priority: "critical" });
  const calendar = new ICAL.Component(ICAL.parse(exportCalendar([task], true, new Date("2027-09-01T00:00:00Z"))));
  const e = calendar.getFirstSubcomponent("vevent");
  assert.equal(e.getFirstPropertyValue("class"), "PRIVATE"); assert.equal(e.getFirstPropertyValue("transp"), "TRANSPARENT");
  assert.equal(e.hasProperty("attendee"), false); assert.equal(e.hasProperty("organizer"), false); assert.equal(calendar.hasProperty("method"), false);
  assert.equal(e.getAllSubcomponents("valarm").length, 4);
  assert.equal(e.getFirstPropertyValue("summary"), "Task • " + task.title);
});
test("completed and date-only tasks have no alarms; archived and cancelled items are excluded", () => {
  const tasks = [makeTask({ title: "Complete", completedAt: "2026-01-01T00:00:00Z", dueAt: "2027-10-07T16:00:00Z" }), makeTask({ title: "Day only", dueAt: "2027-10-07", dateOnly: true }), makeTask({ title: "Cancelled", dueAt: "2027-10-07", dateOnly: true, cancelled: true }), makeTask({ title: "Archived", dueAt: "2027-10-07", dateOnly: true, archived: true })];
  const c = new ICAL.Component(ICAL.parse(exportCalendar(tasks, true, new Date("2027-01-01T00:00:00Z"))));
  assert.equal(c.getAllSubcomponents("vevent").length, 2);
  assert.ok(c.getAllSubcomponents("vevent").every(e => e.getAllSubcomponents("valarm").length === 0));
  assert.equal(c.getAllSubcomponents("vevent")[1].getFirstPropertyValue("dtend").toString(), "2027-10-08");
});
