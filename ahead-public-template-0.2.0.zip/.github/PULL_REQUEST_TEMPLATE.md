## What changes for students?

Describe the concrete behavior and scope.

## Validation

List the checks you ran and relevant limitations. Use synthetic data only.

## Source and privacy behavior

If relevant, describe ownership, coverage, completion preservation, or date handling.

