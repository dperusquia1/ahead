---
name: Bug report
about: Report a reproducible planner problem
title: ""
labels: bug
assignees: ""
---

Describe what happened and what you expected.

Steps to reproduce:
1.
2.
3.

Browser and version:

If relevant, attach a small **fictional** calendar example. Do not include private calendar URLs, student/course records, backups, or credentials. Report security issues through the private route described in SECURITY.md.

