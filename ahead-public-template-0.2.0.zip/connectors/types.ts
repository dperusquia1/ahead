/** The future server adapter boundary. Secrets never belong in records or client bundles. */
export type ProviderId = "canvas" | "moodle" | "blackboard";
export type CoverageState = "complete" | "partial" | "unavailable";
export interface ConnectionContext {
  /** Resolve from authenticated server session, never from an untrusted query parameter. */
  userId: string;
  connectionId: string;
  allowedCourseIds: readonly string[];
  signal?: AbortSignal;
}
export interface SourceRecord {
  /** Canonical identity: provider domain | course ID | object type | stable object ID. */
  key: string;
  courseId: string;
  kind: "assignment" | "preparation" | "quiz_metadata" | "discussion_metadata" | "announcement";
  title: string;
  dueAt: string | null;
  sourceUrl: string;
  revision: string;
}
export interface ConnectorSnapshot {
  attemptedAt: string;
  lastSuccessfulCheckAt: string | null;
  coverage: Record<"tasks" | "requiredPreparation" | "announcements" | "materials", CoverageState>;
  records: SourceRecord[];
  /** Advance only after every intended course/source succeeds. */
  checkpoint: string | null;
  errors: { courseId: string; message: string }[];
}
export interface LearningPlatformConnector {
  id: ProviderId;
  label: string;
  state: "planned" | "available";
  readSnapshot(context: ConnectionContext): Promise<ConnectorSnapshot>;
}
