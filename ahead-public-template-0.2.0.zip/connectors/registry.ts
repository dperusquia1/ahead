import type { LearningPlatformConnector, ProviderId } from "./types.ts";

function planned(id: ProviderId, label: string): LearningPlatformConnector {
  return { id, label, state: "planned", async readSnapshot() { throw new Error(`${label} live connection is not configured.`); } };
}
export const connectorRegistry: readonly LearningPlatformConnector[] = [
  planned("canvas", "Canvas"), planned("moodle", "Moodle"), planned("blackboard", "Blackboard"),
];
