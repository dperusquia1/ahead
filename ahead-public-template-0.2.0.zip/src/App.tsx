import { useEffect, useRef, useState } from "react";
import type { FormEvent, ReactNode } from "react";
import { connectorRegistry } from "../connectors/registry.ts";
import { exportCalendar, mergeCalendar, parseCalendar, zonedTimestamp } from "./calendar.ts";
import type { CalendarPreview } from "./calendar.ts";
import { KINDS, MAX_FILE_BYTES, MAX_TASKS, PRIORITIES, STORAGE_KEY, compareTasks, dayKey, demoPlanner, describeDue, dueDay, emptyPlanner, id, isOverdue, makeTask, minutesLabel, parseBackup, safeUrl } from "./model.ts";
import type { Kind, Planner, Priority, Task } from "./model.ts";

type View = "plan" | "week" | "changes" | "settings";
type Modal = { type: "task"; task?: Task } | { type: "import" } | { type: "restore"; planner: Planner } | { type: "reset" } | null;
const zone = Intl.DateTimeFormat().resolvedOptions().timeZone;
const labels: Record<Kind, string> = { task: "Calendar / general", assignment: "Assignment", preparation: "Preparation", quiz: "Quiz", discussion: "Discussion", meeting: "Meeting" };

function load() {
  let raw: string | null = null;
  try { raw = localStorage.getItem(STORAGE_KEY); }
  catch { return { raw, data: emptyPlanner(), blocked: false, error: "Browser storage is unavailable. You can plan in this tab, but download a backup before leaving." }; }
  try { return { raw, data: raw ? parseBackup(raw) : emptyPlanner(), blocked: false, error: "" }; }
  catch { return { raw, data: emptyPlanner(), blocked: true, error: "Saved data could not be opened. It has not been overwritten. Download the original saved data for recovery, then restore a backup or clear this browser’s planner in Settings." }; }
}
function download(name: string, text: string, type: string) {
  const url = URL.createObjectURL(new Blob([text], { type }));
  const link = document.createElement("a"); link.href = url; link.download = name; link.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export default function App() {
  const [initial] = useState(load);
  const [planner, setPlanner] = useState(initial.data);
  const [demo, setDemo] = useState<Planner | null>(null);
  const [view, setView] = useState<View>("plan");
  const [modal, setModal] = useState<Modal>(null);
  const [storageError, setStorageError] = useState(initial.error);
  const [conflict, setConflict] = useState(false);
  const [toast, setToast] = useState("");
  const [query, setQuery] = useState("");
  const [course, setCourse] = useState("");
  const [filter, setFilter] = useState("open");
  const [timeBudget, setTimeBudget] = useState(0);
  const [reminders, setReminders] = useState(false);
  const [now, setNow] = useState(() => new Date());
  const rawRef = useRef(initial.raw);
  const blockedRef = useRef(initial.blocked);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const backupInput = useRef<HTMLInputElement>(null);
  const data = demo ?? planner;
  const today = dayKey(now);

  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 60000);
    const onStorage = (event: StorageEvent) => { if ((event.key === STORAGE_KEY || event.key === null) && event.newValue !== rawRef.current) setConflict(true); };
    window.addEventListener("storage", onStorage);
    return () => { clearInterval(timer); window.removeEventListener("storage", onStorage); if (toastTimer.current) clearTimeout(toastTimer.current); };
  }, []);

  function notify(message: string) {
    setToast(message); if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(""), 4500);
  }
  function commit(next: Planner, force = false): boolean {
    try { next = parseBackup(JSON.stringify(next)); } catch (error) { notify(error instanceof Error ? error.message : "Invalid data."); return false; }
    if (demo) { setDemo(next); return true; }
    if (blockedRef.current && !force) { notify("Restore a backup or clear the unreadable planner in Settings first."); return false; }
    try {
      if (!force && localStorage.getItem(STORAGE_KEY) !== rawRef.current) { setConflict(true); return false; }
      const raw = JSON.stringify(next); localStorage.setItem(STORAGE_KEY, raw); rawRef.current = raw;
      blockedRef.current = false; setStorageError(""); setConflict(false);
    } catch { blockedRef.current = false; setStorageError("Browser storage is unavailable or full. Changes are only in this tab—download a backup before leaving."); }
    setPlanner(next); return true;
  }
  function reloadSaved() {
    const saved = load(); setPlanner(saved.data); rawRef.current = saved.raw; blockedRef.current = saved.blocked;
    setStorageError(saved.error); setConflict(false);
  }
  function navigate(next: View) { setView(next); window.scrollTo({ top: 0, behavior: "smooth" }); }
  function exploreDemo() { setDemo(demoPlanner()); setCourse(""); setQuery(""); setFilter("open"); setTimeBudget(0); navigate("plan"); }
  function backupCurrent(name = "ahead-backup.json") {
    download(name, !demo && blockedRef.current && rawRef.current !== null ? rawRef.current : JSON.stringify(data, null, 2), "application/json");
  }
  function openImport() { if (demo) notify("Leave the sample week to import your own calendar."); else setModal({ type: "import" }); }
  function complete(task: Task) {
    const next = { ...task, completedAt: task.completedAt ? null : new Date().toISOString() };
    if (commit({ ...data, tasks: data.tasks.map(t => t.id === task.id ? next : t) })) notify(next.completedAt ? "Marked complete. Open the task to record actual time." : "Task reopened.");
  }
  async function readBackup(file?: File) {
    if (!file) return;
    try { if (file.size > MAX_FILE_BYTES) throw new Error("The backup is too large (maximum 2 MB)."); setModal({ type: "restore", planner: parseBackup(await file.text()) }); }
    catch (error) { notify(error instanceof Error ? error.message : "Could not read the backup."); }
  }
  const open = data.tasks.filter(t => !t.archived && !t.completedAt && !t.cancelled);
  const courses = [...new Set(data.tasks.filter(t => !t.archived).map(t => t.course))].sort();
  const tasks = data.tasks.filter(t => (filter === "archived" ? t.archived : !t.archived)
    && (filter !== "open" || (!t.completedAt && !t.cancelled))
    && (filter !== "done" || !!t.completedAt) && (!course || t.course === course)
    && (!timeBudget || t.estimatedMinutes <= timeBudget)
    && `${t.title} ${t.course} ${t.notes}`.toLowerCase().includes(query.toLowerCase())).sort(compareTasks);
  const nextTask = [...open].sort(compareTasks)[0];
  const overdue = open.filter(t => isOverdue(t, now));
  const days = Array.from({ length: 7 }, (_, i) => { const d = new Date(now); d.setDate(d.getDate() + i); return d; });
  const weekEnd = dayKey(days[6]);
  const nextWeek = open.filter(t => { const d = dueDay(t); return d && d >= today && d <= weekEnd; });
  const visible = tasks.map(task => <TaskRow key={task.id} task={task} now={now} onOpen={() => setModal({ type: "task", task })} onComplete={() => complete(task)} />);

  return <main className="app-shell">
    <a className="skip-link" href="#content">Skip to content</a>
    <aside className="sidebar">
      <button className="brand" onClick={() => navigate("plan")} aria-label="Ahead home"><span>A</span><strong>Ahead<span className="brand-period">.</span></strong></button>
      <nav aria-label="Main navigation">{([
        ["plan", "01", "My plan"], ["week", "07", "This week"], ["changes", "↗", "Changes"], ["settings", "··", "Settings"],
      ] as const).map(([key, icon, label]) => <button key={key} className={`nav-item ${view === key ? "active" : ""}`} onClick={() => navigate(key)} aria-current={view === key ? "page" : undefined}><span aria-hidden="true">{icon}</span>{label}</button>)}</nav>
      <div className="sidebar-note"><span className="status-dot" />{demo ? "Sample workspace" : storageError ? "Storage needs attention" : conflict ? "Changes in another tab" : "Saved in this browser"}<small>Version 0.2 · community preview</small></div>
    </aside>
    <section className="workspace" id="content">
      <header className="topbar"><div><p className="eyebrow">{now.toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" })}</p><h1>{view === "plan" ? "Make room for what’s next." : view === "week" ? "See the week ahead." : view === "changes" ? "Keep up with the changes." : "Make Ahead yours."}</h1></div><button className="button dark" onClick={openImport}>Import calendar <span aria-hidden="true">↗</span></button></header>
      {demo && <div className="banner sample"><p><strong>You’re exploring a sample week.</strong> Fictional tasks; changes here are temporary.</p><button onClick={() => { setDemo(null); setFilter("open"); setCourse(""); setQuery(""); }}>Back to my planner →</button></div>}
      {storageError && <div role="alert" className="banner warning"><p>{storageError}</p><button onClick={() => backupCurrent(blockedRef.current ? "ahead-recovery.json" : "ahead-backup.json")}>Download saved data</button></div>}
      {conflict && <div role="alert" className="banner warning"><p>This planner changed in another tab. Your next save is paused to protect those changes.</p><button onClick={reloadSaved}>Reload saved planner</button></div>}

      {(view === "plan" || view === "week") && <>
        {data.tasks.length === 0 ? <section className="welcome"><p className="eyebrow">A little clarity goes a long way</p><h2>Your week starts here.</h2><p>Bring in dates from your school calendar, add the preparation it leaves out, and make a plan that fits your time.</p><div className="actions"><button className="button dark" onClick={() => setModal({ type: "task" })}>＋ Add your first task</button><button className="button secondary" onClick={openImport}>Import an .ics file</button></div><button className="link-button" onClick={exploreDemo}>Explore a sample week <span aria-hidden="true">→</span></button><div className="welcome-note">Your tasks stay in this browser. No account or API key needed.</div></section> : <>
          {view === "plan" && <div className="overview">
            <section className="focus-card"><p className="eyebrow">{nextTask ? "One thing to start with" : "A little breathing room"}</p>{nextTask ? <><div className="focus-heading"><h2>{nextTask.title}</h2><span className={`priority ${nextTask.priority}`}>{nextTask.priority}</span></div><p>{nextTask.course} · {describeDue(nextTask)}</p><div className="focus-bottom"><span>{minutesLabel(nextTask.estimatedMinutes)} estimated{isOverdue(nextTask, now) ? " · past due—check status" : ""}</span><button className="button lime" onClick={() => setModal({ type: "task", task: nextTask })}>View task <span aria-hidden="true">→</span></button></div></> : <><h2>You’ve cleared your open tasks.</h2><p>This reflects your planner. Check your school for work outside your imported calendar.</p><button className="button lime" onClick={() => setModal({ type: "task" })}>Add something new</button></>}</section>
            <section className="week-summary" aria-label="Workload summary"><p className="eyebrow">At a glance</p><div><strong>{open.length}</strong><span>open tasks</span></div><div><strong>{minutesLabel(nextWeek.reduce((n, t) => n + t.estimatedMinutes, 0))}</strong><span>estimated over the next 7 days</span></div><div><strong className={overdue.length ? "overdue" : ""}>{overdue.length}</strong><span>past due · completion unconfirmed</span></div></section>
          </div>}
          <div className="list-heading"><div><p className="eyebrow">Your pace, your plan</p><h2>{view === "week" ? "Next 7 days" : "All your tasks"}</h2></div><button className="button dark" onClick={() => setModal({ type: "task" })}>＋ Add task</button></div>
          <div className="filters"><label className="search"><span className="sr-only">Search tasks</span><input placeholder="Search your tasks…" value={query} onChange={e => setQuery(e.target.value)} /></label><label><span className="sr-only">Course filter</span><select value={course} onChange={e => setCourse(e.target.value)}><option value="">All courses</option>{courses.map(c => <option key={c}>{c}</option>)}</select></label><label><span className="sr-only">Status filter</span><select value={filter} onChange={e => setFilter(e.target.value)}><option value="open">Open</option><option value="all">All active</option><option value="done">Completed</option><option value="archived">Archived</option></select></label><label><span className="sr-only">Time available</span><select value={timeBudget} onChange={e => setTimeBudget(Number(e.target.value))}><option value="0">Any duration</option><option value="15">Up to 15 min</option><option value="30">Up to 30 min</option><option value="60">Up to 1 hour</option></select></label></div>
          {view === "plan" ? <div className="task-list">{visible.length ? visible : <p className="empty">No tasks match these filters.</p>}</div> : <div className="week-list">{tasks.some(t => isOverdue(t, now)) && <section><h3 className="overdue">Past due</h3>{tasks.filter(t => isOverdue(t, now)).map(t => <TaskRow key={t.id} task={t} now={now} onOpen={() => setModal({ type: "task", task: t })} onComplete={() => complete(t)} />)}</section>}{days.map(d => <section key={dayKey(d)}><h3>{dayKey(d) === today ? "Today" : d.toLocaleDateString(undefined, { weekday: "long" })}<small>{d.toLocaleDateString(undefined, { month: "short", day: "numeric" })}</small></h3>{tasks.filter(t => dueDay(t) === dayKey(d) && !isOverdue(t, now)).map(t => <TaskRow key={t.id} task={t} now={now} onOpen={() => setModal({ type: "task", task: t })} onComplete={() => complete(t)} />)}{!tasks.some(t => dueDay(t) === dayKey(d) && !isOverdue(t, now)) && <p className="empty small">No matching tasks in your planner.</p>}</section>)}</div>}
        </>}
        <div className="coverage-note"><span aria-hidden="true">◷</span><p><strong>A calendar is part of the picture.</strong> Imports are snapshots. Re-import to see changes, and check your portal for readings, announcements, materials, and work with no calendar date.</p><button onClick={() => navigate("settings")}>View sources →</button></div>
      </>}

      {view === "changes" && <section className="panel"><div className="list-heading"><div><p className="eyebrow">Observed on import</p><h2>What changed</h2></div><span className="tag">Latest {data.changes.length}</span></div><p className="muted">Date changes appear after you re-import the same calendar. This release does not check your school in the background.</p>{data.changes.length ? data.changes.map(change => <article className="change-row" key={change.id}><span className="change-arrow" aria-hidden="true">↗</span><div><small>{new Date(change.at).toLocaleString()}</small><h3>{change.title}</h3><p>{change.detail}</p></div><button className="icon-button" aria-label={`View ${change.title}`} onClick={() => { const task = data.tasks.find(t => t.id === change.taskId); if (task) setModal({ type: "task", task }); else notify("This task is no longer in this workspace."); }}>→</button></article>) : <p className="empty">Your change history will appear when you import a calendar.</p>}</section>}

      {view === "settings" && <div className="settings-grid">
        <section className="panel"><p className="eyebrow">What’s connected</p><h2>Your sources</h2><p className="muted">No school account is signed in. Calendar files are processed on this device; nothing is sent to a server.</p>{data.sources.map(source => <article className="source-row" key={source.id}><h3>{source.label}</h3><p>Imported {new Date(source.importedAt).toLocaleString()}</p><small>{source.count} supported events · {source.skipped} skipped · calendar coverage only</small></article>)}<button className="button dark" onClick={openImport}>Import or update calendar</button><div className="provider-list">{connectorRegistry.map(provider => <div key={provider.id}><strong>{provider.label} live sign-in</strong><span className="tag">Planned</span></div>)}</div><p className="fine-print">Each live connector needs its own authorized integration. A school email address does not connect a portal or mailbox. Never enter a school password or paste an access token here.</p></section>
        <section className="panel"><p className="eyebrow">Take your plan with you</p><h2>Backups & calendars</h2><p className="muted">Browser data can be cleared. Download a backup regularly; it includes your notes and should be kept private.</p><div className="stack"><button className="button secondary" onClick={() => backupCurrent()}>Download backup (.json)</button><button className="button secondary" disabled={!!demo} onClick={() => backupInput.current?.click()}>Restore backup</button><input ref={backupInput} className="sr-only" type="file" accept=".json,application/json" tabIndex={-1} aria-label="Choose backup file" onChange={e => { void readBackup(e.target.files?.[0]); e.target.value = ""; }} /></div><hr /><label className="check-label"><input type="checkbox" checked={reminders} onChange={e => setReminders(e.target.checked)} />Include future display reminders in calendar export</label><p className="fine-print">Critical: 7d/3d/1d/3h; High: 3d/1d/3h; Medium: 1d/3h; Quick: 3h. Completed and date-only items get no reminders. Calendar apps may handle alarms differently.</p><button className="button dark" onClick={() => { if (!data.tasks.some(t => t.dueAt && !t.archived && !t.cancelled)) { notify("Add a dated task before exporting."); return; } download("ahead-calendar.ics", exportCalendar(data.tasks, reminders), "text/calendar"); }}>Export calendar (.ics)</button><p className="fine-print">Exported events are private and show as free, with no guests. This is a static copy; later completion or changes here do not update an earlier export.</p></section>
        <section className="panel"><p className="eyebrow">On this device</p><h2>Your workspace</h2><p className="muted">Displayed times use <strong>{zone}</strong>. Tasks are stored in this browser profile, without account protection or cloud sync. Use your own device and a separate profile on shared computers.</p><div className="stack"><button className="button secondary" onClick={exploreDemo}>Explore sample week</button><button className="button danger" disabled={!!demo} onClick={() => setModal({ type: "reset" })}>Clear this browser’s planner</button></div></section>
        <section className="panel roadmap-card"><p className="eyebrow">Built to grow</p><h2>From planner to assistant.</h2><p>Available today: tasks, preparation, time estimates, completion, calendar files, and backups.</p><p className="muted">Next: authorized school sign-in, per-student server storage, background updates, and private reminders. AI, email access, and live notifications are not active in this release.</p><small>Open-source preview · MIT licensed</small></section>
      </div>}
      <footer>Ahead <span>·</span> A little foresight, a little more space. <span className="footer-local">{demo ? "Fictional sample data" : "Local planner · no background sync"}</span></footer>
    </section>

    {modal?.type === "task" && <TaskDialog task={modal.task} onClose={() => setModal(null)} onSave={task => { if (!modal.task && data.tasks.length >= MAX_TASKS) { notify("The planner supports up to 2,000 tasks."); return; } if (commit({ ...data, tasks: modal.task ? data.tasks.map(t => t.id === task.id ? task : t) : [...data.tasks, task] })) { setModal(null); notify("Task saved."); } }} />}
    {modal?.type === "import" && <ImportDialog sources={planner.sources} onClose={() => setModal(null)} onImport={(preview, sourceId, label) => { try { if (commit(mergeCalendar(planner, preview, sourceId, label))) { setModal(null); notify(`Imported ${preview.events.length} supported events. Completion and time records preserved.`); } } catch (error) { notify(error instanceof Error ? error.message : "Import failed."); } }} />}
    {modal?.type === "restore" && <Dialog title="Restore this backup?" onClose={() => setModal(null)}><p>This replaces the planner in this browser with {modal.planner.tasks.length} tasks and {modal.planner.sources.length} sources. Download your current backup first if you want to keep it.</p><div className="actions"><button className="button secondary" onClick={() => backupCurrent("ahead-before-restore.json")}>Back up current planner</button><button className="button dark" onClick={() => { if (commit(modal.planner, true)) { setModal(null); notify("Backup restored."); } }}>Replace with backup</button></div></Dialog>}
    {modal?.type === "reset" && <Dialog title="Clear this browser’s planner?" onClose={() => setModal(null)}><p>This removes local tasks, sources, and changes from this browser. It does not change any school portal or calendar. A downloaded backup can restore your planner.</p><div className="actions"><button className="button secondary" onClick={() => backupCurrent("ahead-before-clear.json")}>Download backup first</button><button className="button danger" onClick={() => { if (commit(emptyPlanner(), true)) { setModal(null); setCourse(""); notify("Local planner cleared."); } }}>Clear local planner</button></div></Dialog>}
    {toast && <div className="toast" role="status">{toast}</div>}
  </main>;
}

function TaskRow({ task, now, onOpen, onComplete }: { task: Task; now: Date; onOpen: () => void; onComplete: () => void }) {
  return <article className={`task-row ${task.completedAt ? "completed" : ""}`}>
    <input type="checkbox" checked={!!task.completedAt} disabled={task.cancelled || task.archived} onChange={onComplete} aria-label={`Mark ${task.title} ${task.completedAt ? "incomplete" : "complete"}`} />
    <button className="task-main" onClick={onOpen}><span>{task.course} · {labels[task.kind]}{task.cancelled ? " · cancelled in source" : ""}{task.archived ? " · archived" : ""}</span><h3>{task.title}</h3><small className={isOverdue(task, now) ? "overdue" : ""}>{describeDue(task)}{task.completedAt ? " · completed" : isOverdue(task, now) ? " · past due" : ""}</small></button>
    <div className="task-meta"><span className={`priority ${task.priority}`}>{task.priority}</span><small>{minutesLabel(task.estimatedMinutes)} est.{task.actualMinutes !== null ? ` · ${minutesLabel(task.actualMinutes)} actual` : ""}</small></div><button className="icon-button task-open" onClick={onOpen} aria-label={`Edit ${task.title}`}>↗</button>
  </article>;
}
function Dialog({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => { const dialog = ref.current; dialog?.showModal(); return () => dialog?.close(); }, []);
  return <dialog ref={ref} onCancel={onClose} aria-labelledby="dialog-title"><div className="dialog-heading"><h2 id="dialog-title">{title}</h2><button className="icon-button" onClick={onClose} aria-label="Close dialog">×</button></div>{children}</dialog>;
}
function TaskDialog({ task, onClose, onSave }: { task?: Task; onClose: () => void; onSave: (task: Task) => void }) {
  const initial = task ?? makeTask({ title: "" });
  const date = initial.dueAt ? initial.dateOnly ? initial.dueAt : dayKey(new Date(initial.dueAt)) : "";
  const time = initial.dueAt && !initial.dateOnly ? new Date(initial.dueAt).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", hourCycle: "h23" }) : "";
  const [error, setError] = useState("");
  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); const form = new FormData(event.currentTarget);
    try {
      const title = String(form.get("title") || "").trim(); if (!title) throw new Error("Add a task title.");
      const date = String(form.get("date") || ""); const time = String(form.get("time") || "");
      const estimatedMinutes = Number(form.get("estimate"));
      const actual = String(form.get("actual") || "");
      const sourceUrl = String(form.get("url") || "").trim();
      if (sourceUrl && !safeUrl(sourceUrl)) throw new Error("Use a public-style http(s) source link without passwords or access tokens.");
      const dueAt = initial.sourceId ? initial.dueAt : date ? time ? zonedTimestamp(`${date}T${time}:00`, zone) : date : null;
      onSave({ ...initial, title, course: String(form.get("course") || "").trim() || "General", kind: form.get("kind") as Kind, priority: form.get("priority") as Priority,
        dueAt, dateOnly: initial.sourceId ? initial.dateOnly : !!date && !time, estimatedMinutes, originalEstimateMinutes: task ? task.originalEstimateMinutes : estimatedMinutes,
        actualMinutes: actual === "" ? null : Number(actual), notes: String(form.get("notes") || ""), sourceUrl: initial.sourceId ? initial.sourceUrl : safeUrl(sourceUrl),
      });
    } catch (error) { setError(error instanceof Error ? error.message : "Could not save this task."); }
  }
  return <Dialog title={task ? "A closer look" : "Make a little plan"} onClose={onClose}><form onSubmit={submit} className="task-form">
    {initial.sourceId && <p className="info-note">Imported title and date are controlled by the calendar. Your course label, task type, notes, completion, and time estimates stay yours.</p>}
    <label>Task title<input name="title" required maxLength={300} defaultValue={initial.title} readOnly={!!initial.sourceId} autoFocus /></label>
    <div className="form-grid"><label>Course<input name="course" defaultValue={initial.course} maxLength={120} /></label><label>Type<select name="kind" defaultValue={initial.kind}>{KINDS.map(kind => <option value={kind} key={kind}>{labels[kind]}</option>)}</select></label></div>
    <div className="form-grid"><label>Date<input name="date" type="date" defaultValue={date} readOnly={!!initial.sourceId} /></label><label>Time · {zone}<input name="time" type="time" defaultValue={time} readOnly={!!initial.sourceId} /></label></div>
    <p className="fine-print">Leave time empty if only a date is known. Preparation belongs before the class it is needed for; a meeting time is not a submission deadline.</p>
    <div className="form-grid three"><label>Priority<select name="priority" defaultValue={initial.priority}>{PRIORITIES.map(priority => <option key={priority}>{priority}</option>)}</select></label><label>Estimate (minutes)<input name="estimate" type="number" min="0" max="10080" step="1" required defaultValue={initial.estimatedMinutes} /></label><label>Actual (minutes)<input name="actual" type="number" min="0" max="10080" step="1" defaultValue={initial.actualMinutes ?? ""} /></label></div>
    {task && <p className="fine-print">Original estimate: {minutesLabel(task.originalEstimateMinutes)}{task.completedAt ? ` · completed ${new Date(task.completedAt).toLocaleString()}` : ""}.</p>}
    <label>Your preparation & notes<textarea name="notes" rows={3} maxLength={5000} defaultValue={initial.notes} placeholder="Read, watch, coordinate, print, bring…" /></label>
    {!initial.sourceId && <label>Source link (optional)<input name="url" type="url" maxLength={2000} defaultValue={initial.sourceUrl ?? ""} placeholder="https://…" /></label>}
    {initial.sourceNotes && <details><summary>Original calendar description</summary><p className="source-description">{initial.sourceNotes}</p></details>}
    {initial.sourceUrl && <a className="source-link" href={initial.sourceUrl} target="_blank" rel="noopener noreferrer">Open original source ↗</a>}
    {error && <p role="alert" className="form-error">{error}</p>}
    <div className="dialog-actions">{task && <button type="button" className="link-button" onClick={() => onSave({ ...task, archived: !task.archived })}>{task.archived ? "Restore from archive" : "Archive task"}</button>}<button type="submit" className="button dark">Save task</button></div>
  </form></Dialog>;
}
function ImportDialog({ sources, onClose, onImport }: { sources: Planner["sources"]; onClose: () => void; onImport: (preview: CalendarPreview, sourceId: string, label: string) => void }) {
  const [preview, setPreview] = useState<CalendarPreview | null>(null);
  const [sourceId, setSourceId] = useState(sources[0]?.id || "new");
  const [label, setLabel] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  async function read(file?: File) {
    setPreview(null); setError(""); if (!file) return;
    setBusy(true);
    try { if (file.size > MAX_FILE_BYTES) throw new Error("The calendar is too large (maximum 2 MB)."); setPreview(parseCalendar(await file.text(), zone)); if (!label) setLabel(file.name.replace(/\.ics$/i, "").slice(0, 120)); }
    catch (error) { setError(error instanceof Error ? error.message : "Could not read the file."); }
    finally { setBusy(false); }
  }
  function submit(event: FormEvent) {
    event.preventDefault(); if (!preview) return;
    const existing = sources.find(s => s.id === sourceId);
    const name = (existing?.label ?? label).trim();
    if (!name) { setError("Give this calendar a name."); return; }
    if (!existing && sources.some(s => s.label.toLowerCase() === name.toLowerCase())) { setError("That calendar name already exists. Select it above to update without duplicating tasks."); return; }
    onImport(preview, existing?.id ?? id(), name);
  }
  return <Dialog title="Bring your calendar into Ahead" onClose={onClose}><p className="muted">Download an .ics calendar export from your school portal, then choose it here. The file stays on your device. In Canvas, the calendar feed is usually under Calendar → Calendar Feed.</p><form className="task-form" onSubmit={submit}>
    <label>Import into<select value={sourceId} onChange={e => setSourceId(e.target.value)}><option value="new">New calendar</option>{sources.map(source => <option key={source.id} value={source.id}>Update {source.label}</option>)}</select></label>
    {sourceId === "new" && <label>Calendar name<input value={label} onChange={e => setLabel(e.target.value)} maxLength={120} required placeholder="My school calendar" /></label>}
    <label className="file-picker">Calendar file (.ics)<input type="file" accept=".ics,text/calendar" required onChange={e => { void read(e.target.files?.[0]); }} /></label>
    <p className="fine-print">Re-import into the same calendar to update dates without duplicates. Times without a time zone use {zone}. Recurring events and unsupported times are skipped and reported. Imported event start times may be deadlines or meetings—check each source.</p>
    {busy && <p role="status">Reading calendar…</p>}
    {error && <p role="alert" className="form-error">{error}</p>}
    {preview && <div className="import-preview"><strong>{preview.events.length} supported events · {preview.skipped} skipped</strong><ul>{preview.events.slice(0, 5).map(event => <li key={event.uid}>{event.title}{event.cancelled ? " (cancelled)" : ""}</li>)}</ul>{preview.events.length > 5 && <small>And {preview.events.length - 5} more.</small>}{preview.warnings.length > 0 && <details><summary>Review {preview.warnings.length} import notes</summary><ul>{preview.warnings.map((warning, i) => <li key={i}>{warning}</li>)}</ul></details>}</div>}
    <p className="info-note">This brings in calendar events only. It does not check Pages, announcements, files, submissions, or feedback, and it does not keep itself updated.</p><button className="button dark" disabled={!preview || busy} type="submit">Import {preview ? preview.events.length : ""} events</button>
  </form></Dialog>;
}
