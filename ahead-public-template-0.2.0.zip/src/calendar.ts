import ICAL from "ical.js";
import { MAX_FILE_BYTES, MAX_TASKS, describeDue, id, makeTask, safeUrl, validDateOnly } from "./model.ts";
import type { Planner, Task } from "./model.ts";

export interface ImportedEvent {
  uid: string;
  title: string;
  dueAt: string | null;
  dateOnly: boolean;
  description: string;
  url: string | null;
  cancelled: boolean;
}
export interface CalendarPreview {
  events: ImportedEvent[];
  warnings: string[];
  skipped: number;
}

// Reject ambiguous clock times instead of guessing which side of a DST change was meant.
export function zonedTimestamp(wall: string, zone: string): string {
  const formatter = new Intl.DateTimeFormat("en-CA", { timeZone: zone, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: "h23" });
  const target = Date.parse(`${wall}Z`);
  const partsAt = (ms: number) => {
    const p = Object.fromEntries(formatter.formatToParts(new Date(ms)).map(p => [p.type, p.value]));
    return `${p.year}-${p.month}-${p.day}T${p.hour}:${p.minute}:${p.second}`;
  };
  const offsets = new Set<number>();
  for (let hours = -36; hours <= 36; hours += 6) {
    const ms = target + hours * 3600000;
    offsets.add(Date.parse(`${partsAt(ms)}Z`) - ms);
  }
  const matches = [...offsets].map(offset => target - offset).filter(ms => partsAt(ms) === wall);
  if (matches.length !== 1) throw new Error("ambiguous or nonexistent local time near a daylight-saving change");
  return new Date(matches[0]).toISOString();
}

function eventDate(component: ICAL.Component, fallbackZone: string): Pick<ImportedEvent, "dueAt" | "dateOnly"> {
  const prop = component.getFirstProperty("dtstart");
  if (!prop) throw new Error("no start time");
  const raw = String(prop.toJSON()[3]);
  const datePart = raw.slice(0, 10);
  if (!validDateOnly(datePart)) throw new Error("invalid date");
  const time = prop.getFirstValue() as ICAL.Time;
  if (time.isDate) return { dueAt: datePart, dateOnly: true };
  if (!/^\d{4}-\d{2}-\d{2}T(?:[01]\d|2[0-3]):[0-5]\d:[0-5]\dZ?$/.test(raw)) throw new Error("invalid time");
  if (raw.endsWith("Z")) return { dueAt: new Date(raw).toISOString(), dateOnly: false };
  const tzid = prop.getParameter("tzid") as string | undefined;
  if (tzid && component.getTimeZoneByID(tzid)) return { dueAt: time.toJSDate().toISOString(), dateOnly: false };
  return { dueAt: zonedTimestamp(raw, tzid || fallbackZone), dateOnly: false };
}

export function parseCalendar(text: string, fallbackZone: string): CalendarPreview {
  if (new TextEncoder().encode(text).length > MAX_FILE_BYTES) throw new Error("The calendar is too large (maximum 2 MB).");
  let calendar: ICAL.Component;
  try { calendar = new ICAL.Component(ICAL.parse(text)); } catch { throw new Error("This file is not a valid iCalendar (.ics) file."); }
  if (calendar.name !== "vcalendar") throw new Error("Choose an iCalendar (.ics) file.");
  if (calendar.getFirstPropertyValue("method") === "CANCEL") throw new Error("This file cancels a calendar invitation. Import a calendar export instead.");
  const components = calendar.getAllSubcomponents("vevent");
  if (components.length > MAX_TASKS) throw new Error("Import up to 2,000 calendar events at a time.");
  const warnings: string[] = [];
  if (calendar.getAllSubcomponents("vtodo").length) warnings.push("VTODO tasks are not supported; export calendar events (VEVENT).");
  const seen = new Map<string, { event: ImportedEvent; sequence: number; stamp: string }>();
  let skipped = 0;
  for (const component of components) {
    const title = String(component.getFirstPropertyValue("summary") || "Untitled calendar item").slice(0, 300);
    try {
      if (["rrule", "rdate", "recurrence-id", "exdate", "exrule"].some(key => component.hasProperty(key))) throw new Error("recurring events are not supported yet");
      const uid = String(component.getFirstPropertyValue("uid") || "");
      if (!uid || uid.length > 1000) throw new Error("a stable event UID is required");
      const cancelled = component.getFirstPropertyValue("status") === "CANCELLED";
      const date = cancelled && !component.hasProperty("dtstart") ? { dueAt: null, dateOnly: false } : eventDate(component, fallbackZone);
      const event: ImportedEvent = {
        uid, title, ...date, cancelled,
        description: String(component.getFirstPropertyValue("description") || "").slice(0, 5000),
        url: safeUrl(component.getFirstPropertyValue("url")),
      };
      const sequence = Number(component.getFirstPropertyValue("sequence") || 0);
      if (!Number.isSafeInteger(sequence) || sequence < 0) throw new Error("invalid revision number");
      const stamp = String(component.getFirstPropertyValue("last-modified") || component.getFirstPropertyValue("dtstamp") || "");
      const previous = seen.get(uid);
      if (previous) warnings.push(`${title}: duplicate UID; using the latest revision in this file.`);
      if (!previous || sequence > previous.sequence || (sequence === previous.sequence && stamp >= previous.stamp)) seen.set(uid, { event, sequence, stamp });
    } catch (error) {
      skipped++;
      warnings.push(`${title}: ${error instanceof Error ? error.message : "could not read event"}.`);
    }
  }
  if (!seen.size) throw new Error(`No supported events were found. ${warnings[0] || "The file may be empty."}`);
  return { events: [...seen.values()].map(item => item.event), warnings, skipped };
}

export function mergeCalendar(planner: Planner, preview: CalendarPreview, sourceId: string, label: string, now = new Date()): Planner {
  const timestamp = now.toISOString();
  const changes = [...planner.changes];
  const tasks = planner.tasks.map(task => ({ ...task }));
  for (const event of preview.events) {
    const index = tasks.findIndex(task => task.sourceId === sourceId && task.sourceUid === event.uid);
    const existing = tasks[index];
    // Explicit cancellations are retained for review. Missing entries never delete tasks.
    if (event.cancelled) {
      if (existing && !existing.cancelled) {
        tasks[index] = { ...existing, cancelled: true };
        changes.unshift({ id: id(), taskId: existing.id, at: timestamp, title: existing.title, detail: "The imported calendar explicitly marked this item cancelled. Check the source before changing your plans." });
      }
      continue;
    }
    const fields = { title: event.title, dueAt: event.dueAt, dateOnly: event.dateOnly, sourceNotes: event.description, sourceUrl: event.url, cancelled: false };
    if (existing) {
      const updated = { ...existing, ...fields };
      if (existing.dueAt !== updated.dueAt || existing.dateOnly !== updated.dateOnly) changes.unshift({ id: id(), taskId: existing.id, at: timestamp, title: updated.title, detail: `Date changed: ${describeDue(existing)} → ${describeDue(updated)}.` });
      if (existing.title !== updated.title || existing.cancelled) changes.unshift({ id: id(), taskId: existing.id, at: timestamp, title: updated.title, detail: existing.cancelled ? "This item is active again in the imported calendar. Your completion is preserved." : `Title changed from “${existing.title}”.` });
      tasks[index] = updated;
    } else {
      const task = makeTask({ ...fields, course: label, sourceId, sourceUid: event.uid });
      tasks.push(task);
      changes.unshift({ id: id(), taskId: task.id, at: timestamp, title: task.title, detail: "Added from your calendar file. Check the source for preparation and submission instructions." });
    }
  }
  if (tasks.length > MAX_TASKS) throw new Error("This import would exceed the 2,000-task limit. Archive and back up your older workspace, then start a new one.");
  return {
    ...planner, tasks, changes: changes.slice(0, 200),
    sources: [...planner.sources.filter(source => source.id !== sourceId), { id: sourceId, label, importedAt: timestamp, count: preview.events.length, skipped: preview.skipped }],
  };
}

export function exportCalendar(tasks: Task[], reminders = false, now = new Date()): string {
  const calendar = new ICAL.Component("vcalendar");
  calendar.updatePropertyWithValue("version", "2.0");
  calendar.updatePropertyWithValue("prodid", "-//Ahead//Local Planner//EN");
  const offsets = { critical: [10080, 4320, 1440, 180], high: [4320, 1440, 180], medium: [1440, 180], quick: [180] };
  for (const task of tasks.filter(task => task.dueAt && !task.cancelled && !task.archived)) {
    const event = new ICAL.Component("vevent");
    event.updatePropertyWithValue("uid", `${task.id}@ahead.local`);
    event.updatePropertyWithValue("dtstamp", ICAL.Time.fromJSDate(now, true));
    const start = task.dateOnly ? ICAL.Time.fromDateString(task.dueAt!) : ICAL.Time.fromJSDate(new Date(task.dueAt!), true);
    event.updatePropertyWithValue("dtstart", start);
    const end = start.clone(); end.addDuration(ICAL.Duration.fromSeconds(task.dateOnly ? 86400 : 900));
    event.updatePropertyWithValue("dtend", end);
    event.updatePropertyWithValue("summary", `${task.completedAt ? "✓ " : ""}${task.kind === "preparation" ? "Prep" : task.kind === "meeting" ? "Meeting" : "Task"} • ${task.title}`);
    event.updatePropertyWithValue("description", [task.course, task.notes, task.sourceNotes, task.sourceUrl, "Exported from Ahead. Static copy; later edits here do not update this event."].filter(Boolean).join("\n\n"));
    event.updatePropertyWithValue("class", "PRIVATE");
    event.updatePropertyWithValue("transp", "TRANSPARENT");
    if (reminders && !task.completedAt && !task.dateOnly) {
      for (const minutes of offsets[task.priority]) {
        if (Date.parse(task.dueAt!) - minutes * 60000 <= now.getTime()) continue;
        const alarm = new ICAL.Component("valarm");
        alarm.updatePropertyWithValue("action", "DISPLAY");
        alarm.updatePropertyWithValue("description", task.title);
        alarm.updatePropertyWithValue("trigger", ICAL.Duration.fromSeconds(-minutes * 60));
        event.addSubcomponent(alarm);
      }
    }
    calendar.addSubcomponent(event);
  }
  return calendar.toString() + "\r\n";
}
