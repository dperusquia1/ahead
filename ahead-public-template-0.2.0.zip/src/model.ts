export const KINDS = ["task", "assignment", "preparation", "quiz", "discussion", "meeting"] as const;
export const PRIORITIES = ["critical", "high", "medium", "quick"] as const;
export type Kind = typeof KINDS[number];
export type Priority = typeof PRIORITIES[number];

export interface Task {
  id: string;
  title: string;
  course: string;
  kind: Kind;
  dueAt: string | null;
  dateOnly: boolean;
  priority: Priority;
  estimatedMinutes: number;
  originalEstimateMinutes: number;
  actualMinutes: number | null;
  completedAt: string | null;
  notes: string;
  sourceNotes: string;
  sourceUrl: string | null;
  sourceId: string | null;
  sourceUid: string | null;
  cancelled: boolean;
  archived: boolean;
}

export interface CalendarSource {
  id: string;
  label: string;
  importedAt: string;
  count: number;
  skipped: number;
}
export interface Change {
  id: string;
  taskId: string;
  at: string;
  title: string;
  detail: string;
}
export interface Planner {
  schemaVersion: 1;
  tasks: Task[];
  sources: CalendarSource[];
  changes: Change[];
}
export const STORAGE_KEY = "ahead.planner.v1";
export const MAX_FILE_BYTES = 2_000_000;
export const MAX_TASKS = 2000;
export const emptyPlanner = (): Planner => ({ schemaVersion: 1, tasks: [], sources: [], changes: [] });
export const id = () => crypto.randomUUID();

export function safeUrl(value: unknown): string | null {
  if (typeof value !== "string" || value.length > 2000) return null;
  try {
    const url = new URL(value);
    if (!["https:", "http:"].includes(url.protocol) || url.username || url.password) return null;
    for (const key of url.searchParams.keys()) {
      if (/token|password|secret|authorization|api[_-]?key/i.test(key)) return null;
    }
    return url.href;
  } catch { return null; }
}

export function validDateOnly(value: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = new Date(`${value}T12:00:00Z`);
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value;
}
export function validTimestamp(value: string): boolean {
  return /^\d{4}-\d{2}-\d{2}T(?:[01]\d|2[0-3]):[0-5]\d:[0-5]\d(?:\.\d+)?(?:Z|[+-](?:[01]\d|2[0-3]):[0-5]\d)$/.test(value)
    && validDateOnly(value.slice(0, 10)) && Number.isFinite(Date.parse(value));
}
export function dayKey(date: Date): string {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}
export function dueDay(task: Task): string | null {
  return task.dueAt ? task.dateOnly ? task.dueAt : dayKey(new Date(task.dueAt)) : null;
}
export function isOverdue(task: Task, now = new Date()): boolean {
  if (task.completedAt || task.cancelled || task.archived || !task.dueAt) return false;
  return task.dateOnly ? task.dueAt < dayKey(now) : Date.parse(task.dueAt) < now.getTime();
}
export function compareTasks(a: Task, b: Task): number {
  const at = a.dueAt ? a.dateOnly ? new Date(`${a.dueAt}T23:59:59`).getTime() : Date.parse(a.dueAt) : Infinity;
  const bt = b.dueAt ? b.dateOnly ? new Date(`${b.dueAt}T23:59:59`).getTime() : Date.parse(b.dueAt) : Infinity;
  return Number(!!a.completedAt) - Number(!!b.completedAt) || (at === bt ? 0 : at - bt)
    || PRIORITIES.indexOf(a.priority) - PRIORITIES.indexOf(b.priority) || a.title.localeCompare(b.title);
}
export function describeDue(task: Task): string {
  if (!task.dueAt) return "No date yet";
  if (task.dateOnly) return new Date(`${task.dueAt}T12:00:00`).toLocaleDateString(undefined, { month: "short", day: "numeric" }) + " · no time given";
  return new Date(task.dueAt).toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
}
export function minutesLabel(minutes: number): string {
  if (minutes < 60) return `${minutes} min`;
  return `${Math.floor(minutes / 60)}h${minutes % 60 ? ` ${minutes % 60}m` : ""}`;
}
export function makeTask(fields: Pick<Task, "title"> & Partial<Task>): Task {
  return {
    id: id(), course: "General", kind: "task", dueAt: null, dateOnly: false,
    priority: "medium", estimatedMinutes: 30, originalEstimateMinutes: 30, actualMinutes: null,
    completedAt: null, notes: "", sourceNotes: "", sourceUrl: null, sourceId: null, sourceUid: null,
    cancelled: false, archived: false, ...fields,
  };
}

// Backups and local storage are untrusted input. Validate before touching the workspace.
export function parseBackup(text: string): Planner {
  if (new TextEncoder().encode(text).length > MAX_FILE_BYTES) throw new Error("The file is too large (maximum 2 MB).");
  const data: unknown = JSON.parse(text);
  function obj(v: unknown): Record<string, unknown> {
    if (!v || typeof v !== "object" || Array.isArray(v)) throw new Error("Invalid planner data.");
    return v as Record<string, unknown>;
  }
  function str(v: unknown, limit = 5000): string {
    if (typeof v !== "string" || v.length > limit) throw new Error("Invalid or oversized text in backup.");
    return v;
  }
  function num(v: unknown, max = 10080): number {
    if (typeof v !== "number" || !Number.isInteger(v) || v < 0 || v > max) throw new Error("Invalid number in backup.");
    return v;
  }
  function bool(v: unknown): boolean { if (typeof v !== "boolean") throw new Error("Invalid flag in backup."); return v; }
  function stamp(v: unknown): string { const s = str(v, 40); if (!validTimestamp(s)) throw new Error("Invalid timestamp in backup."); return s; }
  const root = obj(data);
  if (root.schemaVersion !== 1 || !Array.isArray(root.tasks) || !Array.isArray(root.sources) || !Array.isArray(root.changes)) throw new Error("This is not a supported Ahead backup.");
  if (root.tasks.length > MAX_TASKS || root.sources.length > 100 || root.changes.length > 200) throw new Error("This backup exceeds the planner limits.");
  const sources = root.sources.map((v): CalendarSource => {
    const s = obj(v);
    return { id: str(s.id, 200), label: str(s.label, 120), importedAt: stamp(s.importedAt), count: num(s.count, MAX_TASKS), skipped: num(s.skipped, MAX_TASKS) };
  });
  const sourceIds = new Set(sources.map(s => s.id));
  if (sourceIds.size !== sources.length) throw new Error("Duplicate sources in backup.");
  const tasks = root.tasks.map((v): Task => {
    const t = obj(v);
    const dateOnly = bool(t.dateOnly);
    const dueAt = t.dueAt === null ? null : str(t.dueAt, 40);
    if (dueAt && !(dateOnly ? validDateOnly(dueAt) : validTimestamp(dueAt))) throw new Error("Invalid task date.");
    if (!KINDS.includes(t.kind as Kind) || !PRIORITIES.includes(t.priority as Priority)) throw new Error("Invalid task type or priority.");
    const sourceId = t.sourceId === null ? null : str(t.sourceId, 200);
    const sourceUid = t.sourceUid === null ? null : str(t.sourceUid, 1000);
    if (sourceId && (!sourceIds.has(sourceId) || !sourceUid)) throw new Error("Task references an unknown source.");
    if (!sourceId && sourceUid) throw new Error("Task has no source for its identifier.");
    return {
      id: str(t.id, 200), title: str(t.title, 300), course: str(t.course, 120), kind: t.kind as Kind,
      dueAt, dateOnly, priority: t.priority as Priority, estimatedMinutes: num(t.estimatedMinutes),
      originalEstimateMinutes: num(t.originalEstimateMinutes), actualMinutes: t.actualMinutes === null ? null : num(t.actualMinutes),
      completedAt: t.completedAt === null ? null : stamp(t.completedAt), notes: str(t.notes), sourceNotes: str(t.sourceNotes),
      sourceUrl: safeUrl(t.sourceUrl), sourceId, sourceUid, cancelled: bool(t.cancelled), archived: bool(t.archived),
    };
  });
  if (new Set(tasks.map(t => t.id)).size !== tasks.length) throw new Error("Duplicate task identifiers in backup.");
  const identities = tasks.filter(t => t.sourceId).map(t => JSON.stringify([t.sourceId, t.sourceUid]));
  if (new Set(identities).size !== identities.length) throw new Error("Duplicate calendar tasks in backup.");
  const changes = root.changes.map((v): Change => {
    const c = obj(v);
    return { id: str(c.id, 200), taskId: str(c.taskId, 200), at: stamp(c.at), title: str(c.title, 300), detail: str(c.detail, 1000) };
  });
  return { schemaVersion: 1, tasks, sources, changes };
}

export function demoPlanner(now = new Date()): Planner {
  const due = (offset: number, hour: number) => {
    const d = new Date(now); d.setDate(d.getDate() + offset); d.setHours(hour, 0, 0, 0); return d.toISOString();
  };
  const tasks = [
    makeTask({ title: "Customer interview reflection", course: "Entrepreneurship", kind: "assignment", dueAt: due(0, 20), priority: "high", estimatedMinutes: 60, originalEstimateMinutes: 60, notes: "Sample task: review your notes, choose key insights, then write the reflection." }),
    makeTask({ title: "Read the visualization chapter", course: "Data & Decisions", kind: "preparation", dueAt: due(1, 9), estimatedMinutes: 35, originalEstimateMinutes: 35, notes: "Sample preparation: read the chapter and bring two questions to class." }),
    makeTask({ title: "Practice problem set", course: "Data & Decisions", kind: "assignment", dueAt: due(2, 23), estimatedMinutes: 90, originalEstimateMinutes: 90, priority: "high" }),
    makeTask({ title: "Book a team working session", course: "Entrepreneurship", dueAt: due(1, 17), estimatedMinutes: 10, originalEstimateMinutes: 10, priority: "quick" }),
    makeTask({ title: "Review lecture notes", course: "Design Lab", dueAt: due(-1, 15), estimatedMinutes: 25, originalEstimateMinutes: 25, actualMinutes: 20, completedAt: now.toISOString() }),
  ];
  return { schemaVersion: 1, tasks, sources: [], changes: [{ id: id(), taskId: tasks[2].id, at: now.toISOString(), title: tasks[2].title, detail: "Sample change: the deadline moved one day later. No live source was checked." }] };
}
